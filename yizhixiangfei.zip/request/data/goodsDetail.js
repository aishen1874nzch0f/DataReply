// var goodsDetail=()=>{
// 	var data=[];
// 	for(var i=1; i<5;i++){
// 		data.push({
// 			title:"这个产品是采用uni-app技术编辑而成。可以编译成多端语言发布",
// 			image:"https://img-cdn-qiniu.dcloud.net.cn/uploads/example/product"+i+".jpg", 
// 		})
// 	}
// 	return {code:200,message:ok,data:data}
// }
var goodsDetail={
						id:"56",
						title:"南极鲜虾1",
						shop_id:"1",
						image:"https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1544204280691&di=655e46080cb185c45ab6f3d97b972b6a&imgtype=0&src=http%3A%2F%2Fimgsrc.baidu.com%2Fimgad%2Fpic%2Fitem%2Fbf096b63f6246b60e3d2c94ee0f81a4c510fa228.jpg",
						stock:"30",
						price:"128",
						oldprice:"99",
						tip:"特价",
						detail:"南极虾（学名Euphausia superba）又名大磷虾或南极大磷虾，是一种生活在南极洲水域的浮游甲壳动物。磷虾属，于南纬60℃以南的冰缘区域大量聚集。极磷虾是似虾的无脊椎动物，它们以微小的浮游植物作为食物，从中将初级生产而来的能量，转化来维持其远洋带的生命周期。它们是南极生态系统的关键物种，若以生物质能来说，它们可能是地球上最成功的动物物种 （大约共有5亿吨）。",
// 						attribute:[//属性
// 							{
// 								name:"重量",
// 								text:"59g",
// 							},
// 							{
// 								name:"口味",
// 								text:"清淡"
// 							},{
// 								name:"产地",
// 								text:"南极"
// 							}
// 						],
						versionIndex:0,
						version:[//规格-型号-版本
							{
								name:"大盘",
								image:"https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1544204280787&di=64dadf9649f7b6f0f135159cabbe2ae7&imgtype=0&src=http%3A%2F%2Fimgsrc.baidu.com%2Fimgad%2Fpic%2Fitem%2F32fa828ba61ea8d3dd7dc6399c0a304e251f58ab.jpg",
								stock:"5",
								price:"128"
							},{
								name:"小盘",
								price:"98",
								image:"https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1544204280784&di=ae01f30678d452e5a52cf2ca7a3fa53b&imgtype=0&src=http%3A%2F%2Fimg3.redocn.com%2Ftupian%2F20141122%2Fxiaochaoyangroumeishi_3486181.jpg",
								stock:"5",
							},{
								name:"最大最大的大盘",
								price:"198",
								image:"https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1544204280787&di=cfd84df82c675e88976d5cb83049e30d&imgtype=0&src=http%3A%2F%2Fimgsrc.baidu.com%2Fimgad%2Fpic%2Fitem%2Fe824b899a9014c08cbe37399017b02087bf4f436.jpg",
								stock:"5",
							},{
								name:"麻辣口味",
								price:"168",
								image:"https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1544204280696&di=08cc7bcba6c722cf8f63846a472f93c7&imgtype=0&src=http%3A%2F%2Fimgsrc.baidu.com%2Fimgad%2Fpic%2Fitem%2Ffd039245d688d43f1c278dc8761ed21b0ef43b79.jpg",
								stock:"5",
							},{
								name:"鱿鱼酱汁",
								price:"158",
								image:"https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1544204280780&di=ee7c103c75035a690eaf59e3c2a7d1b4&imgtype=0&src=http%3A%2F%2Fpic15.nipic.com%2F20110805%2F2235429_002350120145_2.jpg",
								stock:"5",
							}
						]
						 
				}

export default goodsDetail
